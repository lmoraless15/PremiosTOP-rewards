const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

function toast(m){ const t=$("#toast"); t.textContent=m; t.classList.add("show"); clearTimeout(toast.t); toast.t=setTimeout(()=>t.classList.remove("show"),2200); }
async function copy(txt){
  try { await navigator.clipboard.writeText(txt); }
  catch(e){ const a=document.createElement("textarea"); a.value=txt; document.body.append(a); a.select(); document.execCommand("copy"); a.remove(); }
  toast("Copiado ✔");
}
function art(o, cls=""){
  return o.img ? `<img class="${cls}" src="${esc(o.img)}" alt="${esc(o.name||o.label)}" loading="lazy">`
    : `<div class="art ${cls}" style="--h:${o.hue||0}"><span>${esc(o.icon)}</span></div>`;
}

/* Portada */
function renderHome(){
  $("#demoBadge").textContent = SITE.demoBadge;
  $("#eyebrow").textContent = SITE.eyebrow;
  $("#heroTitle").textContent = SITE.title;
  $("#heroSub").textContent = SITE.sub;
  $("#liveText").textContent = SITE.liveText;
  $("#disclaimer").textContent = SITE.disclaimer;
  $("#grid").innerHTML = EVENTS.map((e,i)=>`
    <article class="card" style="animation-delay:${i*80}ms;--h:${e.hue||0}">
      ${art(e,"card-img")}
      <div class="card-body"><h3>${esc(e.icon)} ${esc(e.name)}</h3><p>${esc(e.desc)}</p>
      <a class="btn" href="#/${esc(e.id)}">Ingresar →</a></div>
    </article>`).join("");
}

/* Detalle de evento */
const progKey = id => "mgff-progress-" + id;
function getDone(id){ try{ return JSON.parse(localStorage.getItem(progKey(id))) || []; }catch(e){ return []; } }
function setDone(id,a){ try{ localStorage.setItem(progKey(id), JSON.stringify(a)); }catch(e){} }

function renderDetail(e){
  const done = getDone(e.id);
  $("#detail").innerHTML = `
    <a class="btn ghost" href="#/">← Volver al menú principal</a>
    <div class="d-hero" style="--h:${e.hue||0}">
      ${art(e,"d-img")}
      <div><p class="eyebrow">${esc(e.icon)} Evento de ejemplo</p><h2>${esc(e.name)}</h2><p class="sub">${esc(e.desc)}</p></div>
    </div>
    <h3 class="sec">Galería</h3>
    <div class="gallery">${e.gallery.map(g=>`<figure>${art({...g,hue:e.hue},"g-img")}<figcaption>${esc(g.label)}</figcaption></figure>`).join("")}</div>
    <h3 class="sec">Tutorial paso a paso</h3>
    <div class="progress"><div class="bar"><i id="bar"></i></div><span id="pct"></span></div>
    <ol class="steps">${e.steps.map((s,i)=>`
      <li id="step${i}" class="${done.includes(i)?"done":""}"><span class="num">${i+1}</span>
        <div><h4>${esc(s.title)}</h4><p>${esc(s.text)}</p>
        <div class="row">
          <button class="btn small" data-done="${i}">${done.includes(i)?"✓ Completado":"Marcar como hecho"}</button>
          ${s.copy?`<button class="btn small ghost" data-copy="${esc(s.copy)}">Copiar texto</button>`:""}
        </div></div></li>`).join("")}</ol>
    <h3 class="sec">Enlaces</h3>
    <div class="links">${e.links.map((l,i)=>`
      <div class="link"><span>${esc(l.label)}</span>
        <button class="btn small" data-link="${i}">Copiar enlace</button>
        ${l.url?`<a class="btn small ghost" href="${esc(l.url)}" target="_blank" rel="noopener noreferrer">Abrir</a>`:""}
      </div>`).join("")}</div>
    <a class="btn ghost" href="#/">← Volver al menú principal</a>`;
  updateProgress(e);
  const d = $("#detail");
  d.onclick = ev => {
    const b = ev.target.closest("button"); if(!b) return;
    if(b.dataset.copy) copy(b.dataset.copy);
    if(b.dataset.link!==undefined){
      const url = e.links[b.dataset.link].url;
      url ? copy(url) : toast("Este enlace aún no está configurado. Editá data.js");
    }
    if(b.dataset.done!==undefined){
      const i = +b.dataset.done, a = getDone(e.id), k = a.indexOf(i);
      k>=0 ? a.splice(k,1) : a.push(i); setDone(e.id,a);
      const li = $("#step"+i); li.classList.toggle("done", k<0);
      b.textContent = k<0 ? "✓ Completado" : "Marcar como hecho";
      updateProgress(e);
    }
  };
}
function updateProgress(e){
  const n = getDone(e.id).filter(i=>i<e.steps.length).length, p = Math.round(n/e.steps.length*100);
  $("#bar").style.width = p+"%"; $("#pct").textContent = `${n}/${e.steps.length} pasos · ${p}%`;
}

/* Rutas por hash: #/ o #/id */
function route(){
  const id = location.hash.replace(/^#\/?/,"");
  const e = EVENTS.find(x=>x.id===id);
  const home = $("#home"), det = $("#detail");
  if(e){ renderDetail(e); home.hidden = true; det.hidden = false; restart(det); }
  else { det.hidden = true; home.hidden = false; restart(home); }
  window.scrollTo({top:0});
}
function restart(el){ el.classList.remove("view"); void el.offsetWidth; el.classList.add("view"); }

/* Chat simulado */
let chatRun = 0;
async function playChat(){
  const run = ++chatRun, box = $("#msgs"); box.innerHTML = "";
  const wait = ms => new Promise(r=>setTimeout(r,ms));
  for(const m of CHAT){
    if(run!==chatRun) return;
    const t = document.createElement("div"); t.className="typing"; t.textContent = m.name+" está escribiendo… (simulado)";
    box.append(t); await wait(900);
    if(run!==chatRun) return;
    t.remove();
    const d = document.createElement("div"); d.className="msg";
    d.innerHTML = `<span class="av">${esc(m.avatar)}</span><div class="bubble"><b>${esc(m.name)}</b><p>${esc(m.text)}</p></div>`;
    box.append(d); box.scrollTop = box.scrollHeight; await wait(500);
  }
}

renderHome();
window.addEventListener("hashchange", route);
$("#chatReset").addEventListener("click", playChat);
route(); playChat();
