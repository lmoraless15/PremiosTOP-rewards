/* ====== CONFIGURACIÓN CENTRAL ======
   Editá este archivo para cambiar textos, eventos, tutoriales, enlaces y chat.
   - img: ruta a una imagen propia (ej: "assets/mi-imagen.jpg"). Si lo dejás vacío "", se usa un arte generado.
   - url: enlace real. Si lo dejás vacío "", el botón avisa que falta configurarlo.
   - Para agregar un evento nuevo, copiá un bloque de EVENTS y cambiá el id.
   Usá solo imágenes propias o con permiso; no uses material oficial como si fuera tuyo. */
const SITE = {
  eyebrow: "Portal independiente de fans",
  title: "Eventos especiales de Free Fire",
  sub: "Guías, tutoriales y novedades de la comunidad MinatoGmrFF. Elegí una categoría y seguí los pasos.",
  demoBadge: "DEMO · contenido de ejemplo",
  liveText: "Indicador de actividad: DEMOSTRACIÓN (no son datos reales)",
  disclaimer: "MinatoGmrFF Rewards es un portal independiente de contenido y tutoriales hecho por fans. No es una página oficial ni está afiliada a Garena. No pedimos contraseñas ni datos de tu cuenta y no garantizamos ninguna recompensa."
};

const EVENTS = [
  {
    id: "diamantes", icon: "💎", hue: 200, name: "Diamantes",
    desc: "Guía para entender cómo funcionan los diamantes y dónde comprarlos de forma segura.",
    img: "",
    gallery: [{img:"",label:"Tienda oficial",icon:"🛒"},{img:"",label:"Métodos de pago",icon:"💳"},{img:"",label:"Seguridad",icon:"🔒"}],
    steps: [
      {title:"Abrí la tienda dentro del juego", text:"Entrá a Free Fire y tocá el ícono de Diamantes en el menú principal.", copy:""},
      {title:"Elegí un paquete", text:"Compará los paquetes y verificá el precio final antes de pagar.", copy:""},
      {title:"Pagá solo por canales oficiales", text:"Nunca compartas tu contraseña ni códigos de verificación con nadie.", copy:"Nunca compartas mi contraseña ni mis códigos de verificación."}
    ],
    links: [{label:"Enlace de la guía (configurable)", url:""}]
  },
  {
    id: "conjuntos", icon: "🥷", hue: 340, name: "Conjuntos y skins",
    desc: "Mostrá los conjuntos y skins de la temporada y cómo se consiguen dentro del juego.",
    img: "",
    gallery: [{img:"",label:"Conjunto A",icon:"🧥"},{img:"",label:"Conjunto B",icon:"🎭"},{img:"",label:"Skin de arma",icon:"🔫"}],
    steps: [
      {title:"Revisá el evento activo", text:"Abrí la pestaña de eventos del juego y buscá el conjunto de la temporada.", copy:""},
      {title:"Leé los requisitos", text:"Cada evento indica cómo se obtiene la recompensa y hasta cuándo dura.", copy:""},
      {title:"Equipalo", text:"Desde el vestuario, seleccioná el conjunto y guardá el cambio.", copy:""}
    ],
    links: [{label:"Enlace de la guía (configurable)", url:""}]
  },
  {
    id: "emotes", icon: "🕺", hue: 285, name: "Emotes",
    desc: "Los emotes más pedidos y cómo equiparlos en tu barra de partida.",
    img: "",
    gallery: [{img:"",label:"Emote 1",icon:"💃"},{img:"",label:"Emote 2",icon:"🤸"},{img:"",label:"Emote 3",icon:"🙌"}],
    steps: [
      {title:"Entrá a Colección", text:"Abrí Colección y tocá la pestaña Emotes.", copy:""},
      {title:"Elegí hasta seis", text:"Tocá un espacio libre y seleccioná el emote.", copy:""},
      {title:"Probalo en el lobby", text:"Usá la vista previa para confirmar que quedó bien.", copy:""}
    ],
    links: [{label:"Enlace de la guía (configurable)", url:""}]
  },
  {
    id: "eventos", icon: "🎁", hue: 20, name: "Recompensas de eventos",
    desc: "Cómo participar en los eventos del juego y reclamar lo que ofrecen oficialmente.",
    img: "",
    gallery: [{img:"",label:"Calendario",icon:"📅"},{img:"",label:"Misiones",icon:"🎯"},{img:"",label:"Reclamar",icon:"✅"}],
    steps: [
      {title:"Abrí la pestaña Eventos", text:"Verificá las fechas de inicio y fin de cada evento.", copy:""},
      {title:"Completá las misiones", text:"Cumplí lo que pide el evento dentro del juego.", copy:""},
      {title:"Reclamá en el juego", text:"Las recompensas se reclaman solo dentro de Free Fire, nunca por mensajes privados.", copy:"Las recompensas se reclaman solo dentro del juego."}
    ],
    links: [{label:"Enlace de la guía (configurable)", url:""}]
  },
  {
    id: "codigos", icon: "🔑", hue: 50, name: "Códigos y tutoriales",
    desc: "Cómo canjear códigos desde el sitio oficial de canje y cómo evitar estafas.",
    img: "",
    gallery: [{img:"",label:"Canje",icon:"⌨️"},{img:"",label:"Verificación",icon:"🛡️"},{img:"",label:"Consejos",icon:"💡"}],
    steps: [
      {title:"Copiá el código", text:"Usá el botón de copiar para no equivocarte al escribirlo.", copy:"TU-CODIGO-AQUI"},
      {title:"Ingresá al sitio oficial de canje", text:"Pegá la URL oficial en la configuración de enlaces y abrila desde allí.", copy:""},
      {title:"Desconfiá de las estafas", text:"Nadie serio te pide tu contraseña para canjear un código.", copy:""}
    ],
    links: [{label:"Sitio de canje (configurable)", url:""}]
  }
];

const CHAT = [
  {name:"Lucía_Demo", avatar:"🦊", text:"¿Alguien probó la guía de emotes?"},
  {name:"Tomi_Ficticio", avatar:"🐺", text:"Sí, quedó muy clara. Los pasos están numerados."},
  {name:"Nico_Ejemplo", avatar:"🦅", text:"Recordá no compartir tu contraseña con nadie."},
  {name:"Lucía_Demo", avatar:"🦊", text:"Totalmente. Solo se reclama dentro del juego."},
  {name:"Maru_Muestra", avatar:"🐯", text:"Esto es una demo, ¡los nombres no son reales!"}
];
